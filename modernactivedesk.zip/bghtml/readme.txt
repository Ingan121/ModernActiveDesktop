Put any HTML wallpaper here to use the wallpaper with the Win98/IE4 Channel Bar.
The main HTML file must be named 'index.html.'

Since Steam automatically updates workshop items and that will reset this folder too, it is recommended to copy the entire project to (SteamLibrary directory)\steamapps\common\wallpaper_engine\projects\myprojects.

The HTML wallpaper is rendered inside an iframe element with a transparent background, so you can still use the background settings in WE if you leave the HTML background transparent.

If your HTML wallpaper has no transparent part, it is recommended to remove the background options in project properties which doesn't change anything visible.