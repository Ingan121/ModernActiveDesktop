# MAD System Plugin Setup Guide
1. Open up the Wallpaper Engine's wallpaper selection window.
2. Right-click this wallpaper.
3. Click 'Open in Explorer'  
![Step 2-3](sysplug1.png)
4. Run the 'Install System Plugin' batch file.  
![Step 4](sysplug2.png)
5. Enter 1.  
![Step 5](sysplug3.png)
6. In the Wallpaper Engine properties panel, check the 'System plugin integration' option.  
![Step 6](sysplug4.png)
7. You are all set!